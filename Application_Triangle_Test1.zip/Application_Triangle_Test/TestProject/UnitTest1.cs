using NUnit.Framework;

namespace TestProject
{
    public class Tests
    {
        [SetUp]
        public void Setup()
        {
        }
        //[TestCase("3", "3", "3")]
        //[TestCase("6", "6", "6")]
        //[TestCase("0", "0", "0")]
        //[TestCase("1", "1", "1")]
        //[TestCase("", "", "")]
        //[TestCase("1,2", "1,2", "1,2")]
        //[TestCase("1.2", "1.2", "1.2")]
        //[TestCase("1/2", "1/2", "1/2")]
        //public void Test1(string a, string b, string c)
        //{
        //    var sut = new Application_Triangle_Test.Triangle();
        //    var expect = "��������������";
        //    var actual = sut.GetTriangleInfo(a,b,c);
        //    Assert.AreEqual(expect, actual.Item1);
        //}
        //���� ����� �� �������� ���� ������������ - ��������������
        [Test]
        public void Test2()
        {
            var sut = new Application_Triangle_Test.Triangle();
            var expect = "��������������";
            var actual = sut.GetTriangleInfo("3", "3", "3");
            Assert.AreEqual(expect, actual.Item1);
        }
        [Test]
        public void Test3()
        {
            var sut = new Application_Triangle_Test.Triangle();
            var expect = "��������������";
            var actual = sut.GetTriangleInfo("1", "1", "1");
            Assert.AreEqual(expect, actual.Item1);
        }
        [Test]
        public void Test4()
        {
            var sut = new Application_Triangle_Test.Triangle();
            var expect = "��������������";
            var actual = sut.GetTriangleInfo("1/2", "1/2", "1/2");
            Assert.AreEqual(expect, actual.Item1);
        }
        [Test]
        public void Test5()
        {
            var sut = new Application_Triangle_Test.Triangle();
            var expect = "��������������";
            var actual = sut.GetTriangleInfo("1.2", "1.2", "1.2");
            Assert.AreEqual(expect, actual.Item1);
        }
        [Test]
        public void Test6()
        {
            var sut = new Application_Triangle_Test.Triangle();
            var expect = "��������������";
            var actual = sut.GetTriangleInfo("1,2", "1,2", "1,2");
            Assert.AreEqual(expect, actual.Item1);
        }
        //����� �� ��� ������������ -��������������
        [Test]
        public void Test7()
        {
            var sut = new Application_Triangle_Test.Triangle();
            var expect = "��������������";
            var actual = sut.GetTriangleInfo("1,2", "1", "1,2");
            Assert.AreEqual(expect, actual.Item1);
        }
        [Test]
        public void Test8()
        {
            var sut = new Application_Triangle_Test.Triangle();
            var expect = "��������������";
            var actual = sut.GetTriangleInfo("2", "1", "2");
            Assert.AreEqual(expect, actual.Item1);
        }
        [Test]
        public void Test9()
        {
            var sut = new Application_Triangle_Test.Triangle();
            var expect = "��������������";
            var actual = sut.GetTriangleInfo("1", "2", "2");
            Assert.AreEqual(expect, actual.Item1);
        }
        [Test]
        public void Test10()
        {
            var sut = new Application_Triangle_Test.Triangle();
            var expect = "��������������";
            var actual = sut.GetTriangleInfo("2", "2", "1");
            Assert.AreEqual(expect, actual.Item1);
        }
        //���� �� ��� ������������ - ��������������
        [Test]
        public void Test11()
        {
            var sut = new Application_Triangle_Test.Triangle();
            var expect = "��������������";
            var actual = sut.GetTriangleInfo("3", "4", "6");
            Assert.AreEqual(expect, actual.Item1);
        }
        [Test]
        public void Test12()
        {
            var sut = new Application_Triangle_Test.Triangle();
            var expect = "��������������";
            var actual = sut.GetTriangleInfo("6", "3", "4");
            Assert.AreEqual(expect, actual.Item1);
        }
        [Test]
        public void Test13()
        {
            var sut = new Application_Triangle_Test.Triangle();
            var expect = "��������������";
            var actual = sut.GetTriangleInfo("6", "3", "4");
            Assert.AreEqual(expect, actual.Item1);
        }
        //�������� �� �� �����������(������ �������� ��� null)
        [Test]
        public void Test14()
        {
            var sut = new Application_Triangle_Test.Triangle();
            var expect = "";
            var actual = sut.GetTriangleInfo("0", "0", "0");
            Assert.AreEqual(expect, actual.Item1);
        }
        [Test]
        public void Test15()
        {
            var sut = new Application_Triangle_Test.Triangle();
            var expect = "";
            var actual = sut.GetTriangleInfo("8", "0", "0");
            Assert.AreEqual(expect, actual.Item1);
        }
        [Test]
        public void Test16()
        {
            var sut = new Application_Triangle_Test.Triangle();
            var expect = "";
            var actual = sut.GetTriangleInfo("0", "6", "0");
            Assert.AreEqual(expect, actual.Item1);
        }
        [Test]
        public void Test17()
        {
            var sut = new Application_Triangle_Test.Triangle();
            var expect = "";
            var actual = sut.GetTriangleInfo("0", "0", "9");
            Assert.AreEqual(expect, actual.Item1);
        }
        [Test]
        public void Test18()
        {
            var sut = new Application_Triangle_Test.Triangle();
            var expect = "";
            var actual = sut.GetTriangleInfo(null, null, null);
            Assert.AreEqual(expect, actual.Item1);
        }
        [Test]
        public void Test19()
        {
            var sut = new Application_Triangle_Test.Triangle();
            var expect = "";
            var actual = sut.GetTriangleInfo(null, null, "9");
            Assert.AreEqual(expect, actual.Item1);
        }
        [Test]
        public void Test20()
        {
            var sut = new Application_Triangle_Test.Triangle();
            var expect = "";
            var actual = sut.GetTriangleInfo(null, "6", null);
            Assert.AreEqual(expect, actual.Item1);
        }
        [Test]
        public void Test21()
        {
            var sut = new Application_Triangle_Test.Triangle();
            var expect = "";
            var actual = sut.GetTriangleInfo(null, "6", "9");
            Assert.AreEqual(expect, actual.Item1);
        }
        [Test]
        public void Test22()
        {
            var sut = new Application_Triangle_Test.Triangle();
            var expect = "";
            var actual = sut.GetTriangleInfo("6", null, null);
            Assert.AreEqual(expect, actual.Item1);
        }
        //���� �� �������������� ������������(�� �����������)
        [Test]
        public void Test23()
        {
            var sut = new Application_Triangle_Test.Triangle();
            var expect = "�� �����������";
            var actual = sut.GetTriangleInfo("6", "87654", "34");
            Assert.AreEqual(expect, actual.Item1);
        }
        [Test]
        public void Test24()
        {
            var sut = new Application_Triangle_Test.Triangle();
            var expect = "�� �����������";
            var actual = sut.GetTriangleInfo("698765", "87", "34");
            Assert.AreEqual(expect, actual.Item1);
        }
        [Test]
        public void Test25()
        {
            var sut = new Application_Triangle_Test.Triangle();
            var expect = "�� �����������";
            var actual = sut.GetTriangleInfo("6", "8", "3498765");
            Assert.AreEqual(expect, actual.Item1);
        }
        [Test]
        public void Test26()
        {
            var sut = new Application_Triangle_Test.Triangle();
            var expect = new List<(int, int)>() { (-2, -2), (-2, -3), (-2, -2) };
            var actual = sut.GetTriangleInfo(null, null, null);
            Assert.AreEqual(expect, actual.Item2);
        }
        [Test]
        public void Test27()
        {
            var sut = new Application_Triangle_Test.Triangle();
            var expect = new List<(int, int)>() { (-2, -2), (-2, -3), (-2, -2) };
            var actual = sut.GetTriangleInfo("1", null, null);
            Assert.AreEqual(expect, actual.Item2);
        }
        [Test]
        public void Test28()
        {
            var sut = new Application_Triangle_Test.Triangle();
            var expect = new List<(int, int)>() { (-2, -2), (-2, -3), (-2, -2) };
            var actual = sut.GetTriangleInfo(null,"1", null);
            Assert.AreEqual(expect, actual.Item2);
        }
        [Test]
        public void Test29()
        {
            var sut = new Application_Triangle_Test.Triangle();
            var expect = new List<(int, int)>() { (-2, -2), (-2, -3), (-2, -2) };
            var actual = sut.GetTriangleInfo(null,null,"1");
            Assert.AreEqual(expect, actual.Item2);
        }
    }
}