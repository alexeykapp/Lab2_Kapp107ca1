﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Application_Triangle_Test.Triangle;

namespace Application_Triangle_Test
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите сторону А");
            string input1 = Console.ReadLine();
            Console.WriteLine("Введите сторону В");
            string input2 = Console.ReadLine();
            Console.WriteLine("Введите сторону С");
            string input3 = Console.ReadLine();
            (string result, List<(int, int)> result1) = new Triangle().GetTriangleInfo(input1, input2, input3);
            Console.WriteLine(result);
           // Console.WriteLine(Convert.ToString(result1));
        }
    }
}
